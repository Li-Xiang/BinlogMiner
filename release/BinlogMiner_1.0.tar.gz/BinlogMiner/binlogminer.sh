java -cp "*:./lib/*"  org.littlestar.mysql.binlog.BinlogMinerApp $@
